# VOID Client — Minecraft Java 1.20.0 / Fabric

VOID Client is a lightweight client-side Fabric mod designed around a dark, translucent, touch-friendly ClickGUI. It is an original implementation inspired only by the general visual language of the supplied reference image; it does not copy its logo, source code, or proprietary assets.

## Target
- Minecraft Java Edition **1.20.0**
- Fabric Loader **0.14.21**
- Fabric API **0.83.0+1.20.0**
- Yarn mappings **1.20+build.1**
- Java 17 bytecode
- Android / ARM64 compatible Java APIs; no Windows-only APIs

## Install on Zalith Launcher
1. Install a Minecraft **1.20.0 Fabric** profile in Zalith Launcher.
2. Launch it once and close it.
3. Open that instance's `.minecraft/mods` folder.
4. Copy `VOIDClient-MC1.20.0-1.0.0.jar` (or the built `VOIDClient-*.jar`) into `mods/`.
5. Put a Fabric API version compatible with Minecraft 1.20.0 in the same `mods/` folder if it is not already installed.
6. Launch Minecraft.
7. Enter a world or server and press **RSHIFT**.

## ClickGUI
- **RSHIFT** toggles the ClickGUI by default.
- Search modules from the top-right search field.
- Click the left portion of a module card to toggle it.
- Click the right side (`>`) to open its settings panel.
- ESC closes the current settings panel or the GUI.
- GUI is non-pausing and works with mouse/touch input through Minecraft's Screen input system.

## Key settings
Open **OTHER → Keybind Manager** to change the key used to open/close the ClickGUI. The selected key is written to Minecraft's options. Default is **RSHIFT**.

## HUD
HUD rendering includes the core display modules and a custom center crosshair preview. Module positions, scale, opacity and enabled state are stored by VOID Client configuration.

## Configs
Files are stored in:

`.minecraft/config/voidclient/`

Examples:
- `default.json`
- `pvp.json`
- `fps.json`

The default config is automatically loaded during client initialization.

## Build
From the project root:

```bash
./gradlew build
```

The remapped production jar is emitted under `build/libs/`.

> **Build note for this delivered archive:** the build was attempted in the generation sandbox, but the sandbox could not resolve `services.gradle.org`, so Gradle could not be bootstrapped. The source archive therefore does **not** pretend that a production JAR was built. See `BUILD_RESULT.txt`.

## Notes
This project intentionally does not implement packet exploits, anti-cheat bypasses, or unauthorized server interference. FPS-related features are client-side controls intended to reduce visual workload on lower-powered devices.
